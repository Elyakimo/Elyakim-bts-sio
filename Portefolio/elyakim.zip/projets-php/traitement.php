<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // trim() retire les espaces avant/après, pour que empty() détecte aussi
    // un champ rempli uniquement d'espaces
    $nom = trim($_POST["nom"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $message = trim($_POST["message"] ?? "");

    // Validation des champs
    if (empty($nom) || empty($email) || empty($message)) {
        echo "Veuillez remplir tous les champs.";
        exit;
    }

    // Correction : filter_var rejette tout ce qui n'est pas un email syntaxiquement
    // valide — ça bloque au passage les tentatives d'injection d'en-têtes, puisqu'un
    // email contenant un retour à la ligne ou "Bcc:" n'est pas un email valide.
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Adresse e-mail invalide.";
        exit;
    }

    // Préparation de l'email
    $destinataire = "eonocia@gmail.com";

    // Correction : encodage du sujet pour que les accents s'affichent correctement
    // même si le client mail du destinataire ne devine pas l'UTF-8 automatiquement
    $sujet = mb_encode_mimeheader("Nouveau message de contact de $nom", "UTF-8");

    $corps = "Nom : $nom\n";
    $corps .= "Email : $email\n";
    $corps .= "Message :\n$message\n";

    // Correction : "From" reste TOUJOURS ta propre adresse (jamais celle du visiteur,
    // ça évite l'injection d'en-têtes ET les problèmes de délivrabilité — beaucoup de
    // serveurs mail rejettent ou classent en spam un message dont le "From" ne
    // correspond pas au nom de domaine qui l'envoie réellement).
    // "Reply-To" contient l'adresse du visiteur : quand tu cliques "Répondre" dans ta
    // boîte mail, la réponse partira bien vers lui.
    $entetes  = "From: Portfolio Contact <eonocia@gmail.com>\r\n";
    $entetes .= "Reply-To: $email\r\n";
    $entetes .= "Content-Type: text/plain; charset=UTF-8\r\n";

    // Envoi de l'email
    if (mail($destinataire, $sujet, $corps, $entetes)) {
        echo "Merci pour votre message. Je vous répondrai dès que possible.";
    } else {
        echo "Une erreur est survenue lors de l'envoi de votre message.";
    }

} else {
    header("HTTP/1.1 403 Forbidden");
    echo "Accès interdit.";
}
header("Location: contact.php?envoi=succes");
exit;
?>