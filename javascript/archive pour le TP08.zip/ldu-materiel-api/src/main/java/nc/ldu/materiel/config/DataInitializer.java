package nc.ldu.materiel.config;

import nc.ldu.materiel.entity.Materiel;
import nc.ldu.materiel.repository.MaterielRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner chargerDonnees(MaterielRepository repository) {
        return args -> {
            repository.save(new Materiel(
                "Ordinateur portable",
                "Informatique",
                "Bon",
                true
            ));

            repository.save(new Materiel(
                "Vidéoprojecteur",
                "Audiovisuel",
                "Moyen",
                false
            ));
        };
    }
}
