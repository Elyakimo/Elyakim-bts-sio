<script setup>
import { onMounted, ref } from 'vue'
import { testerApi } from './services/api.js'

const apiEtat = ref('Vérification de l’API…')

onMounted(async () => {
  try {
    const materiels = await testerApi()
    apiEtat.value = `API Spring Boot joignable — ${materiels.length} matériel(s) reçu(s)`
  } catch {
    apiEtat.value = 'API Spring Boot non joignable — démarrez le backend sur le port 8080'
  }
})
</script>

<template>
  <main class="page">
    <h1>LDU Matériel</h1>
    <p class="techno">Projet de départ — Vue.js</p>

    <section class="controle">
      <h2>État du projet</h2>
      <p>{{ apiEtat }}</p>
    </section>

    <section class="mission">
      <h2>À vous de construire la suite</h2>
      <p>
        Cette application est volontairement minimale. Les composants métier,
        la liste des matériels et les actions seront ajoutés pendant le TP.
      </p>
    </section>
  </main>
</template>
