import { Component } from '@angular/core';
@Component({selector:'app-root',standalone:true,templateUrl:'./app.component.html'})
export class AppComponent { titre='LDU Matériel avec Angular'; }
